---
edit_url: https://github.com/drush-ops/drush/blob/10.x/examples/Commands/SiteAliasAlterCommands.php
---
```php
--8<-- "examples/Commands/SiteAliasAlterCommands.php"
```
