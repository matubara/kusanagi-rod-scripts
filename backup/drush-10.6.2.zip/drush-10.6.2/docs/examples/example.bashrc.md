---
edit_url: https://github.com/drush-ops/drush/blob/10.x/examples/example.bashrc
---
```shell
--8<-- "examples/example.bashrc"
```
